﻿using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using System.Collections.Concurrent;

namespace CSVBatchProcessing.Hubs;

public class ProgressHub : Hub
{
    private readonly IHubContext<ProgressHub> _hubContext;

    public ProgressHub()
    {
        
        Console.WriteLine("ProgressHub created!");
    }

    
}



    







