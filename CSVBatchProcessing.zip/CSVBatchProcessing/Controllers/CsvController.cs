﻿using CSVBatchDal.Model;
using CSVBatchProcessing.DTO;
using CSVBatchProcessing.Hubs;
using CSVBatchProcessing.Services;
using Microsoft.AspNetCore.Connections.Features;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace CSVBatchProcessing.Controllers;

[ApiController]
[Route("[controller]")]
public class CSVController : ControllerBase
{
    private readonly ICSVService _csvService;
    private readonly IHubContext<ProgressHub> _hubContext;

   

    public CSVController(ICSVService csvService, IHubContext<ProgressHub> hubContext)
    {
        _csvService = csvService;
        _hubContext = hubContext;
        
    }


    [HttpPost("upload")]
    public async Task<IActionResult> GetEmployeeCSVAsync([FromForm] IFormFileCollection files)
    {
        try
        {
            if (files == null || files.Count == 0)
            {
                return BadRequest("No files were provided.");
            }
            foreach (var header in Request.Headers)
            {
                Console.WriteLine($"{header.Key}: {header.Value}");
            }
            var UserName = Request.Headers["UserName"];
            var userGuid = Guid.NewGuid().ToString();

            var entities = _csvService.ReadCSV<EntityTbl>(files[0].OpenReadStream());

            foreach (var entity in entities)
            {
                Console.WriteLine($"EntityName: {entity.EntityName}, Description: {entity.Description}, FeatureName: {entity.FeatureName}, FeatureDataType: {entity.FeatureDataType}, Value: {entity.Value}, UserName: {UserName}...");
            }
            //var UserGuid = Request.Headers["UserGuid"];
            await _hubContext.Clients.Client(userGuid).SendAsync("ReceiveUserGuid", userGuid);

            var progress = new Progress<int>(value =>
            {

                _hubContext.Clients.Client(userGuid).SendAsync("ReceiveProgress", value.ToString());
                ///_hubContext.Clients.Client(UserName).SendAsync("ReceiveProgress", value.ToString());

                //_hubContext.Clients.All.SendAsync("ReceiveProgress", value.ToString());  

            });

            await CallApiAsync(entities,UserName,userGuid, progress);
            //await ProcessCSVWithProgress(entities, progress);

            return Ok(new { UserGuid = userGuid, entities });
            //return Ok(entities);
        }
        catch (Exception ex)
        {
            
            Console.WriteLine($"An error occurred while processing the file: {ex}");
            return StatusCode(500, "An error occurred while processing the file.");
        }
    }


    //private async Task CallApiAsync(IEnumerable<EntityTbl> entities, string UserName, IProgress<int> progress)
    //{
    //    string baseApiUrl = "https://featuremarketplacewebapi.azurewebsites.net/api/Feature/AddFeature";

    //    using (var httpClient = new HttpClient())
    //    {
    //        httpClient.BaseAddress = new Uri(baseApiUrl);
    //        httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

    //        if (!string.IsNullOrEmpty(UserName))
    //        {
    //            httpClient.DefaultRequestHeaders.Add("UserName", UserName.ToString());
    //        }

    //        try
    //        {
    //            int totalSteps = entities.Count();
    //            int currentStep = 0;

    //            foreach (var entity in entities)
    //            {
    //                var entityAddRequest = new EntityAddRequest
    //                {
    //                    EntityName = entity.EntityName,
    //                    Description = entity.Description,
    //                    FeatureName = entity.FeatureName,
    //                    FeatureDataType = entity.FeatureDataType,
    //                    Value = entity.Value,
    //                    UserName = UserName,
    //                };

    //                var jsonPayload = Newtonsoft.Json.JsonConvert.SerializeObject(entityAddRequest);
    //                var content = new StringContent(jsonPayload, System.Text.Encoding.UTF8, "application/json");


    //                var response = await httpClient.PostAsync(baseApiUrl, content);

    //                if (!response.IsSuccessStatusCode)
    //                {

    //                    Console.WriteLine($"API call failed for entity {entity.EntityName}. Status code: {response.StatusCode}, Reason: {response.ReasonPhrase}");

    //                    var responseContent = await response.Content.ReadAsStringAsync();
    //                    Console.WriteLine($"Response content: {responseContent}");

    //                    try
    //                    {
    //                        var problemDetails = Newtonsoft.Json.JsonConvert.DeserializeObject<ProblemDetails>(responseContent);
    //                        if (problemDetails != null)
    //                        {
    //                            Console.WriteLine($"Problem Details: {problemDetails.Title}, {problemDetails.Detail}");
    //                        }
    //                    }
    //                    catch (Exception ex)
    //                    {
    //                        Console.WriteLine($"Error parsing problem details: {ex.Message}");
    //                    }

    //                    return;  
    //                }
    //                await Task.Delay(500);
    //                int currentProgress = (currentStep + 1) * 100 / totalSteps;
    //                progress.Report(currentProgress);

    //                currentStep++;
    //            }
    //        }
    //        catch (HttpRequestException ex)
    //        {

    //            Console.WriteLine($"An HTTP request error occurred while calling the API: {ex.Message}");

    //            if (ex.InnerException != null)
    //            {
    //                Console.WriteLine($"Inner Exception: {ex.InnerException.Message}");
    //            }
    //        }
    //        catch (Exception ex)
    //        {

    //            Console.WriteLine($"An error occurred while calling the API: {ex.Message}");
    //        }
    //    }
    //}

    private async Task CallApiAsync(IEnumerable<EntityTbl> entities, string UserName,string userGuid, IProgress<int> progress)
    {
        string baseApiUrl = "https://featuremarketplacewebapi.azurewebsites.net/api/Feature/AddFeature";

        using (var httpClient = new HttpClient())
        {
            httpClient.BaseAddress = new Uri(baseApiUrl);
            httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            if (!string.IsNullOrEmpty(UserName))
            {
                httpClient.DefaultRequestHeaders.Add("UserName", UserName.ToString());
            }

            int totalSteps = entities.Count();
            int currentStep = 0;

            foreach (var entity in entities)
            {
                
        
                 Console.WriteLine($"Processing entity: {entity.EntityName}");

                var entityAddRequest = new EntityAddRequest
                {
                    EntityName = entity.EntityName,
                    Description = entity.Description,
                    FeatureName = entity.FeatureName,
                    FeatureDataType = entity.FeatureDataType,
                    Value = entity.Value,
                    UserName = UserName,
                };

                var jsonPayload = Newtonsoft.Json.JsonConvert.SerializeObject(entityAddRequest);
                var content = new StringContent(jsonPayload, System.Text.Encoding.UTF8, "application/json");

                try
                {
                    
                    var response = await httpClient.PostAsync(baseApiUrl, content);

                    if (!response.IsSuccessStatusCode)
                    {
                        // Handle API call failure if needed
                        Console.WriteLine($"API call failed for entity {entity.EntityName}. Status code: {response.StatusCode}, Reason: {response.ReasonPhrase}");

                        var responseContent = await response.Content.ReadAsStringAsync();
                        Console.WriteLine($"Response content: {responseContent}");

                        try
                        {
                            var problemDetails = Newtonsoft.Json.JsonConvert.DeserializeObject<ProblemDetails>(responseContent);
                            if (problemDetails != null)
                            {
                                Console.WriteLine($"Problem Details: {problemDetails.Title}, {problemDetails.Detail}");
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Error parsing problem details: {ex.Message}");
                        }

                        return;  
                    }

                    await Task.Delay(700);
                    int currentProgress = (currentStep + 1) * 100 / totalSteps;
                    progress.Report(currentProgress);
                }
                catch (HttpRequestException ex)
                {
                   
                    Console.WriteLine($"An HTTP request error occurred while calling the API: {ex.Message}");

                    if (ex.InnerException != null)
                    {
                        Console.WriteLine($"Inner Exception: {ex.InnerException.Message}");
                    }
                }
                catch (Exception ex)
                {
                   
                    Console.WriteLine($"An error occurred while calling the API: {ex.Message}");
                }

                currentStep++;
            }
        }
    }



}