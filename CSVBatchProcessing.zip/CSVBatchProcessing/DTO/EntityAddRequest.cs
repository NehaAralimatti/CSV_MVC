﻿namespace CSVBatchProcessing.DTO;

public class EntityAddRequest
{
    public string EntityName { get; set; }
    
    public string Description { get; set; }

    public string FeatureName { get; set; }
    public string FeatureDataType { get; set; }
    public string Value { get; set; }

    public string UserName {  get; set; }
}
