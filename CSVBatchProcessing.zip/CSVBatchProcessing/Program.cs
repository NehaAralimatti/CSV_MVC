using Microsoft.EntityFrameworkCore;

using Microsoft.OpenApi.Models;

using CSVBatchProcessing.Hubs;
using CSVBatchProcessing.Services;

namespace CSVBatchProcessing;

    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            //var myconstring = builder.Configuration.GetConnectionString("UserMgmtStr");

            ConfigureServices(builder.Services);
            var app = builder.Build();

            Configure(app);

            app.Run();
        }

        static void ConfigureServices(IServiceCollection services)
        {
            services.AddControllersWithViews();
        services.AddControllers(options => options.EnableEndpointRouting = false);
        services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "CSV service", Version = "v1" });
            });

            services.AddScoped<ICSVService, CsvService>();


            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder

                        .AllowAnyHeader()
                        .AllowCredentials()
                        .AllowAnyMethod()
                        .SetIsOriginAllowed(_ => true));
            });

            services.AddSignalR();
        services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

    }

    static void Configure(WebApplication app)
        {
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "CSV service V1");
            });

            app.UseStaticFiles();

            app.UseRouting();

            app.UseCors("CorsPolicy");

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHub<ProgressHub>("/progressHub");
                endpoints.MapControllers();
            });

            app.MapDefaultControllerRoute();
        }
    }

