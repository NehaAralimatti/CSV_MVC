﻿using CsvHelper;
using CsvHelper.Configuration;
using System.Formats.Asn1;
using System.Globalization;

namespace CSVBatchProcessing.Services;

//public class CsvService : ICSVService
//{
//    public List<T> ReadCSV<T>(Stream file)
//    {
//        var reader = new StreamReader(file);
//        var csv = new CsvReader(reader, CultureInfo.InvariantCulture);

//        var records = csv.GetRecords<T>().ToList();

//        return records;
//    }
//}

public class CsvService : ICSVService
{
    public List<T> ReadCSV<T>(Stream file)
    {
        var reader = new StreamReader(file);
        var csvConfig = new CsvConfiguration(CultureInfo.InvariantCulture)
        {
            
            HeaderValidated = null,
            MissingFieldFound = null,
        };
        var csv = new CsvReader(reader, csvConfig);

        var records = csv.GetRecords<T>().ToList();

        return records;
    }
}
