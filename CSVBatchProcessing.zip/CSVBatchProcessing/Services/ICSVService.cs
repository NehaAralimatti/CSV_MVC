﻿namespace CSVBatchProcessing.Services;

public interface ICSVService
{
    List<T> ReadCSV<T>(Stream file);
}
